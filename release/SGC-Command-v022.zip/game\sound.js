'use strict';
// ===================== SGC COMMAND v3 – Strudel & Switch Angel Core Sound Engine =====================
// Lizenz: AGPL-3.0-or-later (voll kompatibel mit @strudel/web & Switch Angel Prebake).
// Features:
// 1. Echte @strudel/web (Superdough WebAudio) Integration inkl. Switch Angel Prebake
//    (acidenv, rlpf, rhpf, dly, trancegate, fill, grab, mpan, vstruct, fmtime, pk, acid,
//    stxt, sf, swap, setScale, sc, ifit, comb, noisehat, zap, roller, roller2, spinor,
//    up, oneshot, filtval, glide, glitch, sq, strum, humanize, bend, track, ar, blockArrange).
// 2. 20 originale Switch Angel Songs (aus Switch-Angel/*.txt) + 6 SGC Core Tracks.
// 3. Voller Strudel-REPL & Mondo-Transpiler ($KICK:, _$RISER:, HAT$:, slider(), mondo`...`).
// 4. Prozedurale Offline-Sample-Synthese (WAV Data-URIs für bd, sd, hh, oh, cp, rim, cb, lt,
//    cr, brk Amen-Break, piano, swpad, ctvox + tr909/mc303 Banks), damit jeder Switch-Angel-Song
//    sofort ohne externe GitHub-Abhängigkeit mit vollem Drum-/Breakbeat-/Synth-Sound läuft.
// 5. Dynamische Missions-Adaption (Tension-System) + Generative Pattern-Mutation + Speichern
//    eigener/mutierter Versionen im Spielstand (S.customTracks).

const _NOTE_SEMI={c:0,'c#':1,db:1,d:2,'d#':3,eb:3,e:4,f:5,'f#':6,gb:6,g:7,'g#':8,ab:8,a:9,'a#':10,bb:10,b:11};
const _SCALE_INTERVALS={
  minor:[0,2,3,5,7,8,10],
  major:[0,2,4,5,7,9,11],
  phrygian:[0,1,3,5,7,8,10],
  pentatonic:[0,3,5,7,10],
  'major:pentatonic':[0,2,4,7,9],
  'minor:pentatonic':[0,3,5,7,10]
};
const _CHORD_MAP={
  dm:[50,53,57,60],dm7:[50,53,57,60],dm9:[50,53,57,60,64],
  am:[45,48,52,55],am7:[45,48,52,55],amin7:[45,48,52,55],
  cm:[48,51,55,58],cm7:[48,51,55,58],cmaj7:[48,52,55,59],
  fm:[41,44,48,51],fmaj7:[41,45,48,52],'f-7':[41,44,48,51],
  gm:[43,46,50,53],gm7:[43,46,50,53],gmaj7:[43,47,50,54],
  em7:[40,43,47,50],bbmaj7:[46,50,53,57],abmaj7:[44,48,51,55],
  ebmaj7:[51,55,58,62],phryg:[38,39,45,50],
};

function _parseNoteToken(tok,scaleStr){
  if(tok===null||tok===undefined)return null;
  const s=String(tok).trim().toLowerCase().replace(/@\d+(\.\d+)?/g,'');
  if(!s||s==='~'||s==='-'||s==='_'||s==='rest')return null;
  if(/^[+-]?\d+$/.test(s)){
    const num=parseInt(s,10);
    if(scaleStr||num<24){
      const scParts=String(scaleStr||'e:minor').toLowerCase().split(':');
      const rootMatch=(scParts[0]||'e').match(/^([a-g][#b]?)(\d+)?$/);
      const rootSemi=rootMatch&&_NOTE_SEMI[rootMatch[1]]!==undefined?_NOTE_SEMI[rootMatch[1]]:4;
      const rootOct=rootMatch&&rootMatch[2]?parseInt(rootMatch[2],10):3;
      const scType=scParts.slice(1).join(':')||'minor';
      const ivs=_SCALE_INTERVALS[scType]||_SCALE_INTERVALS.minor;
      const len=ivs.length;
      const octShift=Math.floor(num/len);
      const deg=((num%len)+len)%len;
      return (rootOct+1+octShift)*12+rootSemi+ivs[deg];
    }
    return num>0?num:null;
  }
  const m=s.match(/^([a-g][#b]?)(-?\d+)?$/);
  if(!m)return null;
  const semi=_NOTE_SEMI[m[1]];
  if(semi===undefined)return null;
  const oct=m[2]!==undefined?parseInt(m[2],10):3;
  return (oct+1)*12+semi;
}

function _midiToFreq(midi){
  return 440*Math.pow(2,(midi-69)/12);
}

// ===================== Mondo & Switch-Angel REPL Transpiler =====================
function _splitTopHash(str){
  const parts=[];let cur='',depth=0;
  for(let i=0;i<str.length;i++){
    const ch=str[i];
    if(ch==='('||ch==='['||ch==='<')depth++;
    else if(ch===')'||ch===']'||ch==='>')depth=Math.max(0,depth-1);
    if(ch==='#'&&depth===0){parts.push(cur.trim());cur='';}
    else cur+=ch;
  }
  if(cur.trim())parts.push(cur.trim());
  return parts;
}
function _tokenizeMondoStep(step){
  const toks=[];let cur='',depth=0;
  for(let i=0;i<step.length;i++){
    const ch=step[i];
    if(ch==='('||ch==='['||ch==='<'){depth++;cur+=ch;}
    else if(ch===')'||ch===']'||ch==='>'){depth=Math.max(0,depth-1);cur+=ch;}
    else if(/\s/.test(ch)&&depth===0){if(cur){toks.push(cur);cur='';}}
    else cur+=ch;
  }
  if(cur)toks.push(cur);
  return toks;
}
function _formatMondoArg(arg,defs){
  arg=arg.trim();
  if(arg.startsWith('(')&&arg.endsWith(')'))return _transpileMondoExpr(arg.slice(1,-1),defs);
  if(defs&&defs.has(arg))return arg;
  if(/^[+-]?(\d+(\.\d*)?|\.\d+)$/.test(arg))return arg;
  if(['rand','sine','tri','saw','square','perlin','irand'].includes(arg))return arg;
  let s=arg;
  if(s.startsWith('[')&&s.endsWith(']')&&s.includes(','))s=s.slice(1,-1);
  s=s.replace(/<_\s+/g,'<~ ').replace(/\|_/g,'|~');
  return JSON.stringify(s);
}
function _transpileMondoExpr(expr,defs){
  expr=expr.trim();
  if(expr.startsWith('#')){
    return '(_x => '+_transpileMondoChain(expr.slice(1).trim(),defs,'_x')+')';
  }
  return _transpileMondoChain(expr,defs,null);
}
function _transpileMondoChain(str,defs,receiver){
  const steps=_splitTopHash(str);
  let out=receiver;
  steps.forEach((st,idx)=>{
    const toks=_tokenizeMondoStep(st);
    if(!toks.length)return;
    if(idx===0&&!out){
      if(toks.length===1)out=_formatMondoArg(toks[0],defs);
      else out=toks[0]+'('+toks.slice(1).map(a=>_formatMondoArg(a,defs)).join(', ')+')';
    }else{
      out=out+'.'+toks[0]+'('+toks.slice(1).map(a=>_formatMondoArg(a,defs)).join(', ')+')';
    }
  });
  return out||'silence';
}

function preprocessSwitchAngelCode(code){
  let src=String(code||'');
  // 1. Transpile mondo`...` blocks into standard Strudel JS
  src=src.replace(/mondo\s*`([\s\S]*?)`/g,(_,body)=>{
    const lines=body.split(/\r?\n/).map(l=>l.replace(/\/\/.*$/,'').trim()).filter(Boolean);
    const statements=[];let cur='';
    for(const l of lines){
      if(l.startsWith('$')){if(cur)statements.push(cur.trim());cur=l.slice(1).trim();}
      else cur+=' '+l;
    }
    if(cur)statements.push(cur.trim());
    const defs=new Set(),jsLines=[];
    for(const st of statements){
      if(st.startsWith('def ')){
        const m=st.match(/^def\s+([a-zA-Z0-9_]+)\s+([\s\S]+)$/);
        if(m){defs.add(m[1]);jsLines.push('const '+m[1]+' = '+JSON.stringify(m[2].trim())+';');}
      }else{
        jsLines.push('$: '+_transpileMondoChain(st,defs,null));
      }
    }
    return jsLines.join('\n');
  });

  // 2. Normalize template literals chained with methods: note(`...`.sub(...)) -> note(`...`).sub(...)
  src=src.replace(/\b(n|note)\(\s*(`[\s\S]*?`)\s*\.((?:sub|add|mul|div|seg|rib)\s*\([^)]*\))\s*\)/g,
    (m, fn, tpl, call) => `${fn}(${tpl}).${call}`
  );
  // Normalize string literals chained inside n("str".seg(...).sub(...)) -> n("str").seg(...).sub(...)
  src=src.replace(/\b(n|note)\(\s*((?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'))\s*\.((?:(?:sub|add|mul|div|seg|rib|ribbon)\s*\([^)]*\)\s*\.?)+)\s*\)/g,
    (m, fn, str, chain) => `${fn}(${str}).${chain.replace(/\.\s*$/, '')}`
  );
  // Chained string assigned to variable: const bpat = "str".sub(7).add(0) -> const bpat = n("str").sub(7).add(0)
  src=src.replace(/(=\s*)((?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'))\s*\.((?:(?:sub|add|mul|div|seg|rib)\s*\([^)]*\)\s*\.?)+)/g,
    (m, eq, str, chain) => `${eq}n(${str}).${chain.replace(/\.\s*$/, '')}`
  );

  // 3. Normalize delaysync -> delay
  src=src.replace(/\.delaysync\(/g, '.delay(');

  // 4. Normalize HAT$: to $HAT:
  src=src.replace(/^(\s*)([A-Za-z0-9_]+)\$\s*:/gm,'$1$$$2:');

  // 5. Make remote github sample calls and Ableton tout non-blocking so offline play never stalls
  src=src.replace(/^\s*samples\s*\(\s*['"]github:[^'"]+['"]\s*\)\s*;?/gm,'// [offline-synth] $&');
  src=src.replace(/\.midi\(['"]tout['"]\)/g, '// .midi("tout")');

  // 6. 8-Bit Chiptune mode waveform rewrite
  if(typeof STRUDEL!=='undefined'&&STRUDEL.chiptuneMode){
    src=src.replace(/\.s\(\s*["'](?:supersaw|sawtooth|triangle|sine|wt_[^"']*)["']\s*\)/g, '.s("square")');
  }

  return src;
}

// ===================== Prozeduraler WAV-Generator für @strudel/web Samples =====================
function _encodeWavDataUri(samplesFloat32,sampleRate){
  const sr=sampleRate||22050,len=samplesFloat32.length;
  const buf=new ArrayBuffer(44+len*2),v=new DataView(buf);
  const wStr=(off,s)=>{for(let i=0;i<s.length;i++)v.setUint8(off+i,s.charCodeAt(i));};
  wStr(0,'RIFF');v.setUint32(4,36+len*2,true);wStr(8,'WAVE');
  wStr(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);
  v.setUint32(24,sr,true);v.setUint32(28,sr*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);
  wStr(36,'data');v.setUint32(40,len*2,true);
  for(let i=0;i<len;i++){
    const s=Math.max(-1,Math.min(1,samplesFloat32[i]));
    v.setInt16(44+i*2,s<0?s*0x8000:s*0x7FFF,true);
  }
  let bin='';const bytes=new Uint8Array(buf);
  for(let i=0;i<bytes.length;i++)bin+=String.fromCharCode(bytes[i]);
  return 'data:audio/wav;base64,'+btoa(bin);
}

function _buildProceduralSampleMap(){
  if(typeof btoa!=='function')return null;
  const sr=22050;
  const mk=(dur,fn)=>{
    const n=Math.floor(sr*dur),a=new Float32Array(n);
    for(let i=0;i<n;i++)a[i]=fn(i/sr,i,n);
    return _encodeWavDataUri(a,sr);
  };
  // 6 Kick variations (bd:0 .. bd:5)
  const bds=[0,1,2,3,4,5].map(v=>mk(0.38,(t)=>{
    const f0=110+v*18,f1=36+v*2;
    const freq=f1+(f0-f1)*Math.exp(-t*28);
    const body=Math.sin(2*Math.PI*freq*t)*Math.exp(-t*8.5);
    const click=(Math.random()*2-1)*Math.exp(-t*90)*0.45;
    return Math.tanh((body+click)*(1.5+v*0.15));
  }));
  // Snare variations (sd:0 .. sd:6)
  const sds=[0,1,2,3,4,5,6].map(v=>mk(0.26,(t)=>{
    const tone=Math.sin(2*Math.PI*(180+v*12)*t)*Math.exp(-t*22)*0.55;
    const noise=(Math.random()*2-1)*Math.exp(-t*(13+v))*0.8;
    return Math.tanh((tone+noise)*1.4);
  }));
  // Closed Hi-Hats (hh:0 .. hh:4) - Roland TR-909 style crisp sizzle
  const hhs=[0,1,2,3,4].map(v=>mk(0.09,(t)=>{
    const n=(Math.random()*2-1);
    const m=Math.sin(2*Math.PI*3820*t)+Math.sin(2*Math.PI*5400*t)+Math.sin(2*Math.PI*7100*t)+Math.sin(2*Math.PI*9200*t);
    return (n*0.75 + m*0.25) * Math.exp(-t*(55+v*8));
  }));
  // Open Hi-Hats (oh:0 .. oh:3) - Smooth airy tail, no metallic cowbell resonance
  const ohs=[0,1,2,3].map(v=>mk(0.32,(t)=>{
    const n=(Math.random()*2-1);
    const m=Math.sin(2*Math.PI*3900*t)+Math.sin(2*Math.PI*5600*t)+Math.sin(2*Math.PI*7300*t)+Math.sin(2*Math.PI*9500*t);
    return (n*0.8 + m*0.2) * Math.exp(-t*(14+v*2));
  }));
  // Clap (cp:0 .. cp:2)
  const cps=[0,1,2].map(v=>mk(0.24,(t)=>{
    const burst=(t<0.012||t>0.018&&t<0.030||t>0.036)?Math.exp(-(t%0.018)*80):0.2;
    return (Math.random()*2-1)*burst*Math.exp(-t*14);
  }));
  // Rimshot, Cowbell, Low Tom, Crash
  const rim=[mk(0.08,t=>Math.sin(2*Math.PI*1450*t)*Math.exp(-t*65)*0.9+Math.sin(2*Math.PI*480*t)*Math.exp(-t*45)*0.6)];
  const cb=[mk(0.18,t=>(Math.sin(2*Math.PI*587*t)*0.5+Math.sin(2*Math.PI*845*t)*0.5)*Math.exp(-t*26)*0.35)];
  const lt=[mk(0.28,t=>Math.sin(2*Math.PI*(90+80*Math.exp(-t*18))*t)*Math.exp(-t*11)*0.9)];
  const cr=[mk(0.85,t=>((Math.random()*2-1)*0.7+Math.sin(t*6200)*0.3)*Math.exp(-t*3.8))];
  // Piano (electric / grand hybrid)
  const piano=[mk(1.2,t=>{
    const f=261.63; // C4 base
    const w=Math.sin(2*Math.PI*f*t)*0.65+Math.sin(4*Math.PI*f*t)*0.22*Math.exp(-t*4)+Math.sin(6*Math.PI*f*t)*0.08*Math.exp(-t*8);
    return w*Math.min(1,t/0.006)*Math.exp(-t*2.6);
  })];
  // Amen-style 16-step Breakbeat loop (brk) for .fit() and .scrub()!
  const brk=[mk(1.75,(t)=>{
    const stepLen=1.75/16,step=Math.floor(t/stepLen),st=t-step*stepLen;
    // Classic Amen pattern: K on 0,2,10; S on 4,7,9,12,15; HH on all
    const isK=[0,2,10,11].includes(step);
    const isS=[4,7,9,12,15].includes(step);
    let sig=((Math.random()*2-1)*0.3+Math.sin(st*5800)*0.15)*Math.exp(-st*32); // hat
    if(isK){
      const kf=42+110*Math.exp(-st*30);
      sig+=Math.sin(2*Math.PI*kf*st)*Math.exp(-st*10)*0.95;
    }
    if(isS){
      sig+=(Math.sin(2*Math.PI*210*st)*0.4+(Math.random()*2-1)*0.75)*Math.exp(-st*16);
    }
    return Math.tanh(sig*1.3);
  })];
  const swpad=[mk(1.5,t=>(Math.sin(2*Math.PI*220*t)+Math.sin(2*Math.PI*329.6*t)*0.7)*Math.min(1,t/0.2)*Math.exp(-t*1.8)*0.4)];
  const ctvox=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17].map(v=>mk(0.35,t=>{
    const f=220*Math.pow(2,(v%12)/12);
    const form=Math.sin(2*Math.PI*f*t)*0.5+Math.sin(2*Math.PI*f*3*t)*0.3;
    return form*Math.min(1,t/0.02)*Math.exp(-t*6);
  }));
  const spspell=[mk(0.55,t=>{
    const f=150*Math.exp(-t*2.5);
    const v=Math.sin(2*Math.PI*f*t)*0.5+Math.sin(2*Math.PI*850*t)*0.3*Math.exp(-t*3)+Math.sin(2*Math.PI*2200*t)*0.2;
    return Math.tanh(v*1.8)*Math.exp(-t*1.8);
  })];
  return {
    bd:bds, sbd:bds, sd:sds, hh:hhs, oh:ohs, cp:cps, rim, cb, lt, cr, piano, brk, swpad, ctvox,
    tr909_bd:bds, tr909_sd:sds, tr909_hh:hhs, tr909_oh:ohs, tr909_cp:cps, tr909_rim:rim, tr909_lt:lt,
    mc303_sd:sds, mc303_bd:bds, mc303_hh:hhs,
    spspell
  };
}

// ===================== Mini-Notation Parser (für Node-Tests & Fallback-Synth) =====================
function parseMiniNotation(expr,cycleIndex){
  if(Array.isArray(expr)){
    const n=expr.length||1;
    return expr.map((v,i)=>({val:v,offset:i/n,dur:1/n}));
  }
  let str=String(expr||'').trim();
  if(!str)return [];
  str=str.replace(/<([^<>]+)>/g,(_,inner)=>{
    const parts=inner.trim().split(/\s+/).filter(Boolean);
    if(!parts.length)return '~';
    return parts[Math.abs(cycleIndex)%parts.length];
  });
  const tokens=[];
  let i=0;
  while(i<str.length){
    while(i<str.length&&/[\s,]/.test(str[i]))i++;
    if(i>=str.length)break;
    if(str[i]==='['){
      let depth=1,start=i+1;i++;
      while(i<str.length&&depth>0){
        if(str[i]==='[')depth++;
        else if(str[i]===']')depth--;
        i++;
      }
      const sub=str.slice(start,i-1).trim().split(/[\s,|]+/).filter(Boolean);
      tokens.push({type:'group',items:sub});
    }else{
      let start=i;
      while(i<str.length&&!/[\s,\[\]]/.test(str[i]))i++;
      const raw=str.slice(start,i).replace(/\/\d+(\.\d+)?$/,'');
      const mult=raw.match(/^([^*\s!]+)[*!](\d+)$/);
      if(mult){
        const count=Math.max(1,Math.min(32,parseInt(mult[2],10)));
        tokens.push({type:'group',items:Array(count).fill(mult[1])});
      }else{
        tokens.push({type:'atom',val:raw});
      }
    }
  }
  if(!tokens.length)return [];
  const events=[],stepDur=1/tokens.length;
  tokens.forEach((t,idx)=>{
    const baseOff=idx*stepDur;
    if(t.type==='atom'){
      events.push({val:t.val,offset:baseOff,dur:stepDur});
    }else if(t.items&&t.items.length){
      const subDur=stepDur/t.items.length;
      t.items.forEach((sv,si)=>{
        events.push({val:sv,offset:baseOff+si*subDur,dur:subDur});
      });
    }
  });
  return events;
}

class StrudelVoice{
  constructor(kind,pattern){
    this.kind=kind;
    this.pattern=pattern;
    this.synth='triangle';
    this.scaleName='e:minor';
    this.transposeSemi=0;
    this.degreePattern=null;
    this.chordName=null;
    this.envPattern=null;
    this._lpf=1800;this._hpf=0;this._gain=0.14;
    this._attack=0.01;this._decay=0.18;this._sustain=0.2;this._release=0.06;
    this._delay=0;this._room=0;this._pan=0;this._fast=1;this._slow=1;this._slide=0;
  }
  s(v){this.synth=String(v||'triangle').split(',')[0].split(':')[0].trim();return this;}
  sound(v){return this.s(v);}
  piano(){return this.s('piano');}
  note(v){if(this.kind==='sound')this.kind='note';this.pattern=v;return this;}
  n(v){if(this.pattern===undefined||this.kind==='sound')this.pattern=v;else this.degreePattern=v;return this;}
  scale(v){this.scaleName=String(v||'e:minor');return this;}
  sc(){this.scaleName=STRUDEL._currentScale||'e:minor';return this;}
  trans(v){this.transposeSemi+=Number(v)||0;return this;}
  transpose(v){return this.trans(v);}
  add(v){return this;}
  sub(v){this.transposeSemi-=Number(v)||0;return this;}
  voicing(){return this;}
  anchor(){return this;}
  env(v){this.envPattern=v;return this;}
  lpf(v){const n=typeof v==='number'?v:1200;this._lpf=Math.max(80,Math.min(12000,n));return this;}
  rlpf(v){const n=typeof v==='number'?v:0.5;this._lpf=Math.max(100,Math.min(10000,Math.pow(n*12,4)));return this;}
  rlp(v){return this.lpf(v);}
  hpf(v){const n=typeof v==='number'?v:0;this._hpf=Math.max(0,Math.min(8000,n));return this;}
  rhpf(v){return this.hpf(v);}
  acidenv(v){const n=typeof v==='number'?v:0.5;this._lpf=Math.max(180,Math.min(4800,220+n*3200));this._decay=0.14;return this;}
  lpenv(){return this;}lps(){return this;}lpd(){return this;}lpq(){return this;}lpa(){return this;}lpattack(){return this;}lpr(){return this;}
  gain(v){const n=typeof v==='number'?v:0.15;this._gain=Math.max(0.01,Math.min(0.6,n*0.22));return this;}
  postgain(v){return this;}
  velocity(){return this;}
  attack(v){const n=typeof v==='number'?v:0.01;this._attack=Math.max(0.002,Math.min(1.5,n));return this;}
  att(v){return this.attack(v);}
  decay(v){const n=typeof v==='number'?v:0.18;this._decay=Math.max(0.01,Math.min(2.5,n));return this;}
  dec(v){return this.decay(v);}
  sustain(v){const n=typeof v==='number'?v:0.2;this._sustain=Math.max(0,Math.min(1,n));return this;}
  sus(v){return this.sustain(v);}
  release(v){const n=typeof v==='number'?v:0.06;this._release=Math.max(0.01,Math.min(2.5,n));return this;}
  rel(v){return this.release(v);}
  delay(v){const n=typeof v==='number'?v:0.25;this._delay=Math.max(0,Math.min(0.85,n));return this;}
  dly(v){return this.delay(v);}
  delaytime(){return this;}delaysync(){return this;}delayfeedback(){return this;}
  room(v){const n=typeof v==='number'?v:0.25;this._room=Math.max(0,Math.min(0.9,n));this._delay=Math.max(this._delay,this._room*0.35);return this;}
  roomsize(){return this;}dry(){return this;}ir(){return this;}irbegin(){return this;}
  pan(v){const n=typeof v==='number'?v:0;this._pan=Math.max(-1,Math.min(1,n));return this;}
  fast(v){const n=typeof v==='number'?v:1;this._fast=Math.max(0.25,Math.min(8,n));return this;}
  slow(v){const n=typeof v==='number'?v:1;this._slow=Math.max(0.25,Math.min(8,n));return this;}
  slide(v){this._slide=Number(v)||0;return this;}
  glide(){return this;}
  seg(){return this;}rib(){return this;}ribbon(){return this;}
  duck(){return this;}duckdepth(){return this;}duckattack(){return this;}
  diode(){return this;}dist(){return this;}
  unison(){return this;}detune(){return this;}wt(){return this;}wtrate(){return this;}warp(){return this;}warpmode(){return this;}
  fm(){return this;}fmh(){return this;}fmtime(){return this;}fmwave(){return this;}
  pw(){return this;}pwrate(){return this;}phaser(){return this;}vib(){return this;}vibmod(){return this;}
  penv(){return this;}pdec(){return this;}clip(){return this;}cut(){return this;}
  o(){return this;}orbit(){return this;}
  bank(){return this;}nine(){return this;}
  trancegate(){return this;}tgate(){return this;}
  fit(){return this;}ifit(){return this;}scrub(){return this;}begin(){return this;}
  almostNever(){return this;}sometimesBy(){return this;}sb(){return this;}degradeBy(){return this;}ply(){return this;}
  jux(){return this;}swingBy(){return this;}beat(){return this;}struct(){return this;}
  stxt(){return this;}
  _pianoroll(){return this;}pianoroll(){return this;}_scope(){return this;}scope(){return this;}
  play(){STRUDEL.registerVoice(this);return this;}
}

// ===================== 6 SGC Core Tracks + 20 Switch Angel Tracks =====================
const STRUDEL_TRACKS={
  base:{
    name:'SGC Basis – Cheyenne Mountain Telemetry',
    artist:'SGC Core',
    role:'base',
    code:`// SGC Basis – Cheyenne Mountain Telemetry (Strudel Pattern)
setcps(0.42)
stack(
  note("<d2 d2 bb1 a1> [~ d2] <f2 g2 a1>").s("sawtooth").lpf(420).decay(0.28).sustain(0.2).gain(0.18),
  note("<d4 f4 a4 c5> <a4 f4 e4 d4> [f4 a4] <c5 e5>").s("triangle").lpf(1600).decay(0.16).sustain(0.08).delay(0.25).room(0.35).gain(0.13),
  s("white*8").lpf(3200).decay(0.025).sustain(0).gain(0.03)
)`
  },
  map:{
    name:'Sternenkarte – Deep Space Cartography',
    artist:'SGC Core',
    role:'map',
    code:`// Sternenkarte – Deep Space Cartography (Strudel Pattern)
setcps(0.34)
stack(
  note("<c2 g2 f2 g2>").s("sine").attack(0.12).decay(0.6).sustain(0.4).gain(0.2),
  note("[c4 e4 g4 b4] <d4 f4 a4 c5> [e4 g4 b4 d5] <g4 b4 d5 f5>").s("triangle").lpf(2100).decay(0.24).delay(0.45).room(0.55).gain(0.12),
  note("<g5 ~ e5 ~> <~ a5 ~ d5>").s("sine").attack(0.04).decay(0.35).delay(0.5).gain(0.08)
)`
  },
  planet:{
    name:'Offworld Kolonie – Planetary Survey',
    artist:'SGC Core',
    role:'planet',
    code:`// Offworld Kolonie – Planetary Survey (Strudel Pattern)
setcps(0.40)
stack(
  note("<e2 e2 g2 a2> [~ e2] <b1 c2 d2>").s("triangle").lpf(620).decay(0.26).sustain(0.22).gain(0.18),
  note("[e4 g4 b4] <d4 f#4 a4> [g4 b4 d5] <a4 c5 e5>").s("sine").lpf(1900).decay(0.20).delay(0.35).room(0.45).gain(0.13),
  s("pink*8").lpf(2600).decay(0.03).gain(0.03)
)`
  },
  gate:{
    name:'Stargate – Wormhole Event Horizon',
    artist:'SGC Core',
    role:'gate',
    code:`// Stargate – Wormhole Event Horizon (Strudel Pattern)
setcps(0.55)
stack(
  note("<e2 b1 c2 a1>*2").s("sawtooth").lpf(680).decay(0.2).sustain(0.25).gain(0.2),
  note("[e4 g4 b4 e5]*2 <[d4 f#4 a4 d5] [c4 e4 g4 c5]>").s("sine").lpf(2800).decay(0.14).delay(0.4).room(0.6).gain(0.14),
  s("pink*16").lpf(2400).decay(0.02).gain(0.04)
)`
  },
  combat:{
    name:'Gefecht – Jaffa Tactical Assault',
    artist:'SGC Core',
    role:'combat',
    code:`// Gefecht – Jaffa Tactical Assault (Strudel Pattern)
setcps(0.52)
stack(
  note("[d2 d2 ~ d2] [f2 d2 g2 gs2]").s("sawtooth").lpf(720).decay(0.14).sustain(0.15).gain(0.24),
  note("<[d4 f4 a4] [d4 eb4 a4]> [~ f4 e4 d4] <[bb3 d4 f4] [a3 cs4 g4]>").s("square").lpf(1450).decay(0.12).sustain(0.08).delay(0.2).gain(0.14),
  s("white*8 [white*4 ~]").lpf(3800).decay(0.035).sustain(0).gain(0.06)
)`
  },
  peaceful:{
    name:'Erstkontakt – Abydos & Nox Harmony',
    artist:'SGC Core',
    role:'peaceful',
    code:`// Friedlicher Erstkontakt – Abydos & Nox Harmony (Strudel Pattern)
setcps(0.32)
stack(
  note("<f2 c3 bb2 c3>").s("sine").attack(0.15).decay(0.7).sustain(0.5).gain(0.18),
  note("<[f4 a4 c5] [g4 bb4 d5] [a4 c5 e5] [g4 c5 e5]>").s("triangle").lpf(1900).attack(0.04).decay(0.35).delay(0.45).room(0.5).gain(0.12)
)`
  },
  boss:{
    name:"Systemlord – Ha'tak Command Bridge",
    artist:'SGC Core',
    role:'boss',
    code:`// Boss-Gefecht – Systemlord Ha'tak Command (Strudel Pattern)
setcps(0.60)
stack(
  note("[c2 c2 db2 c2] [c2 g1 ab1 g1]").s("sawtooth").lpf(900).decay(0.15).sustain(0.25).gain(0.26),
  note("[c4 db4 g4 ab4]*2 <[eb4db4 c4 b3] [f4 eb4 db4 c4]>").s("square").lpf(1850).decay(0.11).delay(0.25).gain(0.16),
  s("white*16").lpf(4400).decay(0.03).gain(0.07)
)`
  }
};

// Merge Switch Angel tracks into STRUDEL_TRACKS if loaded
if(typeof SWITCH_ANGEL_TRACKS!=='undefined'){
  for(const [k,v] of Object.entries(SWITCH_ANGEL_TRACKS)){
    STRUDEL_TRACKS[k]={
      name:`⚡ ${v.title} (Switch Angel)`,
      artist:'Switch Angel',
      role:v.role||'combat',
      bpm:v.bpm||140,
      style:v.style||'Live Strudel',
      code:v.code
    };
  }
}

function _makeDistortionCurve(amount){
  const k=typeof amount==='number'?Math.max(0,amount):10;
  if(k<=0.001){
    const c=new Float32Array(2);c[0]=-1;c[1]=1;return c;
  }
  const n_samples=44100;
  const curve=new Float32Array(n_samples);
  const deg=Math.PI/180;
  for(let i=0;i<n_samples;++i){
    const x=(i*2)/n_samples-1;
    curve[i]=((3+k)*x*20*deg)/(Math.PI+k*Math.abs(x));
  }
  return curve;
}

const STRUDEL={
  cps:0.45,
  voices:[],
  playing:false,
  paused:false,
  chiptuneMode:false,
  _manualChiptune:false,
  currentTrack:'sa_lets_talk',
  mode:'auto', // 'auto' | trackKey | 'custom'
  useSwitchAngelAuto:true, // Nutzt Switch Angel Tracks dynamisch für Missionen & Basis
  dynamicEnabled:true,     // Passt Soundtrack dynamisch an Missions-Spannung an
  tension:0.2,             // 0.0 (ruhig) .. 1.0 (kritisch/Boss)
  mutationCount:0,
  customCode:'',
  lastCode:'',
  cycleIndex:0,
  _timer:null,
  _currentScale:'e:minor',
  webBundleLoaded:false,
  webRepl:null,
  _webInitPromise:null,
  patterns:Object.fromEntries(Object.entries(STRUDEL_TRACKS).map(([k,v])=>[k,v.code])),

  onVoiceTrigger(voice, val){
    if(voice==='kick'||(voice==='bass'&&val<45)){
      if(typeof ISO!=='undefined')ISO.beatPulse=1.0;
    }
    if(typeof WINAMP!=='undefined'&&WINAMP.handleVoiceTrigger){
      WINAMP.handleVoiceTrigger(voice,val);
    }
  },

  get currentCode(){
    return this.lastCode||(this.patterns[this.currentTrack]||'');
  },
  noteToFreq(tok){const m=_parseNoteToken(tok);return m!==null?_midiToFreq(m):0;},
  parseMini(expr,cycle=0){return parseMiniNotation(expr,cycle);},
  compilePattern(code){const v=this.compile(code);return {cps:this.cps,voices:v};},
  play(trackKey){if(typeof SFX!=='undefined')SFX.playTrack(trackKey);},

  setcps(v){this.cps=Math.max(0.15,Math.min(2.0,Number(v)||0.45));return this;},
  setCps(v){return this.setcps(v);},
  setCpm(cpm){this.cps=Math.max(0.15,Math.min(2.0,(Number(cpm)||35)/60));return this;},
  setcpm(cpm){return this.setCpm(cpm);},
  setTempo(bpm){this.cps=Math.max(0.15,Math.min(2.0,(Number(bpm)||96)/240));return this;},
  registerVoice(v){if(v&&!this.voices.includes(v))this.voices.push(v);return v;},

  setChiptune(enabled,manual=false){
    this.chiptuneMode=!!enabled;
    if(manual)this._manualChiptune=!!enabled;
    if(this.playing){
      const cur=this.currentCode;
      this.evaluate(cur,true);
    }
    if(typeof updateWinampDisplay==='function')updateWinampDisplay();
  },

  // Initialisiert das echte @strudel/web REPL + Switch Angel Prebake + Offline-Samples
  async ensureWebRepl(){
    if(this.webRepl)return this.webRepl;
    if(this._webInitPromise)return this._webInitPromise;
    if(typeof window==='undefined'||typeof window.initStrudel!=='function'||typeof window.strudel==='undefined')return null;
    this._webInitPromise=(async()=>{
      try{
        const repl=await window.initStrudel();
        const st=window.strudel;
        if(typeof st.setDefaultAudioContext==='function'&&SFX&&SFX.ctx){
          try{st.setDefaultAudioContext(SFX.ctx);}catch(e){}
        }
        // 1. Register missing CodeMirror / REPL widget helpers without clobbering postgain
        window.slider=(v)=>((typeof st.pure==='function')?st.pure(v!==undefined?v:0.5):(v!==undefined?v:0.5));
        window.sliderWithID=(id,v)=>window.slider(v);
        window.pk=function(...args){
          const control=args.length>2?args.pop():0;
          if(typeof window.pick==='function')return window.pick(args,control);
          if(st&&typeof st.pick==='function')return st.pick(args,control);
          return args[0]||'Dm';
        };
        st.evalScope({
          sliderWithID:window.sliderWithID,
          slider:window.slider,
          pk:window.pk,
          pick:typeof st.pick==='function'?st.pick:((a)=>Array.isArray(a)?a[0]:a)
        });
        ['_scope','scope','_pianoroll','pianoroll','_punchcard','punchcard'].forEach(fn=>{
          st.Pattern.prototype[fn]=function(){return this;};
        });
        st.register('delaysync',(amt,pat)=>pat.delay(amt).delaytime(amt));
        st.Pattern.prototype.delaysync=function(amt){return this.delay(amt).delaytime(amt);};
        st.register('piano',pat=>pat.s('piano'));
        st.register('rlp',(x,pat)=>pat.lpf(x));
        st.register('sb',(p,fn,pat)=>pat.sometimesBy(p,fn));
        // 2. Evaluate Switch Angel's prebake (1).strudel
        if(typeof SWITCH_ANGEL_PREBAKE==='string'){
          await repl.evaluate(SWITCH_ANGEL_PREBAKE,false);
        }
        st.register('tgate',(d,s,l,x)=>x.trancegate(d,s,l));
        // 3. Register Synth Aliases & Procedural Sample Banks so all Switch Angel tracks sound rich
        ['wt_digital','wt_digi','wt_digital_bad_day','wt_digital_basique','wt_digital_echoes','bstab'].forEach(alias=>{
          try{st.soundAlias(alias,'supersaw');}catch(e){}
        });
        const sampleMap=_buildProceduralSampleMap();
        if(sampleMap){
          try{await st.samples(sampleMap,'');}catch(e){}
        }
        if(typeof st.setTriggerFunc==='function'){
          try{
            st.setTriggerFunc(ev=>{
              try{
                const s=String(ev.s||ev.val||'').toLowerCase();
                if(s.includes('bd')||s.includes('sbd')||s.includes('kick')) STRUDEL.onVoiceTrigger('kick',36);
                else if(s.includes('hh')||s.includes('oh')||s.includes('hat')) STRUDEL.onVoiceTrigger('hat',42);
                else if(s.includes('sd')||s.includes('cp')||s.includes('snare')) STRUDEL.onVoiceTrigger('snare',38);
                else if(s.includes('bass')||ev.synth==='sawtooth'||ev.synth==='square') STRUDEL.onVoiceTrigger('bass',40);
                else STRUDEL.onVoiceTrigger('melody',60);
              }catch(err){}
            });
          }catch(err){}
        }
        this.webRepl=repl;
        this.webBundleLoaded=true;
        return repl;
      }catch(e){
        console.warn('[Strudel Web init fallback]',e);
        return null;
      }
    })();
    return this._webInitPromise;
  },

  // Kompiliert ein Strudel- oder Switch-Angel-Skript (auch für Node test-browser.js + Fallback-Synth)
  compile(rawCode){
    const src=preprocessSwitchAngelCode(rawCode).trim();
    if(!src)return [];
    this.voices=[];
    const collected=[];
    const makeProxyNum=(val)=>{
      const n= Number(val)||0.5;
      return n;
    };
    // Extend String & Number prototypes safely for mini-notation chaining in fallback compiler
    if(!String.prototype._saPatched){
      Object.defineProperty(String.prototype,'_saPatched',{value:true});
      ['sub','add','mul','div','seg','rib','ribbon','as'].forEach(m=>{
        if(!String.prototype[m])Object.defineProperty(String.prototype,m,{value:function(){return String(this);},configurable:true});
      });
    }
    if(!Number.prototype._saPatched){
      Object.defineProperty(Number.prototype,'_saPatched',{value:true});
      ['mul','add','sub','div','pow','rib','ribbon','fast','slow','range'].forEach(m=>{
        if(!Number.prototype[m])Object.defineProperty(Number.prototype,m,{value:function(b){
          if(m==='mul')return Number(this)*(Number(b)||1);
          if(m==='add')return Number(this)+(Number(b)||0);
          if(m==='sub')return Number(this)-(Number(b)||0);
          if(m==='pow')return Math.pow(Number(this),Number(b)||1);
          return Number(this);
        },configurable:true});
      });
    }
    const note=p=>{const v=new StrudelVoice('note',p);collected.push(v);return v;};
    const n=p=>{const v=new StrudelVoice('n',p);collected.push(v);return v;};
    const chord=p=>{const v=new StrudelVoice('chord',p);collected.push(v);return v;};
    const s=p=>{const v=new StrudelVoice('sound',p);v.synth=String(p||'white').split(/[*!:,/]/)[0].trim();collected.push(v);return v;};
    const sound=s;
    const stack=(...items)=>{items.flat().forEach(it=>{if(it instanceof StrudelVoice&&!this.voices.includes(it))this.voices.push(it);});return items[0]||new StrudelVoice('sound','~');};
    const cat=(...items)=>stack(...items);
    const seq=(...items)=>stack(...items);
    const blockArrange=(arr)=>stack(...(Array.isArray(arr)?arr.map(x=>Array.isArray(x)?x[0]:x).flat():[]));
    const setcps=v=>this.setcps(v);
    const setCps=v=>this.setcps(v);
    const setCpm=v=>this.setCpm(v);
    const setcpm=v=>this.setCpm(v);
    const setTempo=v=>this.setTempo(v);
    const setScale=sc=>{this._currentScale=String(sc||'e:minor');};
    const slider=(v)=>makeProxyNum(v);
    const all=()=>this;
    const postgain=v=>v;
    const register=()=>this;
    const samples=()=>Promise.resolve();
    const pk=(...args)=>args[0]||'Dm';
    const hush=()=>this.hush();
    const sigObj={
      range:(a,b)=>({slow:()=>(a+b)/2,fast:()=>(a+b)/2,mul:()=>(a+b)/2}),
      fast:()=>sigObj,slow:()=>sigObj,rib:()=>sigObj,ribbon:()=>sigObj,
      mul:()=>sigObj,div:()=>sigObj,add:()=>sigObj,sub:()=>sigObj,seg:()=>sigObj,seed:()=>sigObj,mod:()=>sigObj
    };
    // Transpile muted _$NAME: blocks out and convert $NAME: / $: into __v(expr)
    let jsSrc=src.replace(/^\s*_\$[A-Za-z0-9_]*\s*:[\s\S]*?(?=^\s*(?:_\$|\$[A-Za-z0-9_]*\s*:|const\s+|let\s+|setCpm|setcps|all\s*\()|\s*$)/gm,'');
    jsSrc=jsSrc.replace(/^\s*\$[A-Za-z0-9_]*\s*:\s*/gm,'__v=');
    try{
      const fn=new Function(
        '__v','setcps','setCps','setCpm','setcpm','setTempo','setScale','slider','all','postgain','register','samples','pk',
        'stack','cat','seq','blockArrange','note','n','chord','s','sound','hush',
        'sine','tri','saw','square','rand','irand','perlin','time','rev','iter',
        'G2','D3','C2','A2','E2','F2',
        jsSrc
      );
      fn(
        null,setcps,setCps,setCpm,setcpm,setTempo,setScale,slider,all,postgain,register,samples,pk,
        stack,cat,seq,blockArrange,note,n,chord,s,sound,hush,
        sigObj,sigObj,sigObj,sigObj,sigObj,()=>sigObj,sigObj,sigObj,x=>x,x=>x,
        43,50,36,45,40,41
      );
    }catch(e){
      // Fallback: use collected voices
    }
    if(!this.voices.length&&collected.length)this.voices=collected.slice();
    this.lastCode=String(rawCode||'').trim();
    return this.voices;
  },

  async evaluate(code,autoplay=true){
    const raw=String(code||'').trim();
    this.compile(raw);
    if(typeof window!=='undefined'&&SFX&&SFX.ctx&&!SFX.muted&&SFX.musicEnabled){
      const repl=await this.ensureWebRepl();
      if(repl){
        try{
          if(this._timer){clearInterval(this._timer);this._timer=null;}
          const clean=preprocessSwitchAngelCode(raw);
          await repl.evaluate(clean,autoplay);
          this.playing=!!autoplay;
          this.paused=false;
          if(typeof updateWinampDisplay==='function')updateWinampDisplay();
          return this.voices;
        }catch(e){
          console.warn('[Strudel Web eval fallback to internal synth]',e);
          if(autoplay){
            this.start(true); // force internal synth fallback
            return this.voices;
          }
        }
      }
    }
    if(autoplay)this.start();
    return this.voices;
  },

  hush(){
    this.playing=false;
    this.paused=false;
    if(this._timer){clearInterval(this._timer);this._timer=null;}
    if(this.webRepl&&typeof this.webRepl.stop==='function'){
      try{this.webRepl.stop();}catch(e){}
    }
    if(typeof window!=='undefined'&&typeof window.hush==='function'){
      try{window.hush();}catch(e){}
    }
    if(typeof updateWinampDisplay==='function')updateWinampDisplay();
  },

  start(forceFallback=false){
    if(this._timer)clearInterval(this._timer);
    this.playing=true;
    this.paused=false;
    if(typeof window==='undefined'||!SFX.ctx||SFX.muted||!SFX.musicEnabled)return;
    if(this.webRepl&&!forceFallback){
      const clean=preprocessSwitchAngelCode(this.lastCode||this.currentCode);
      this.webRepl.evaluate(clean,true).catch((e)=>{
        console.warn('[Strudel Web start fallback to internal synth]',e);
        this.start(true);
      });
      return;
    }
    const tick=()=>{
      if(!this.playing||!SFX.ctx||SFX.muted||!SFX.musicEnabled)return;
      const cycleDur=1/Math.max(0.2,this.cps);
      this._triggerCycle(this.cycleIndex++,cycleDur);
    };
    tick();
    this._timer=setInterval(tick,Math.round(1000/Math.max(0.2,this.cps)));
    if(typeof updateWinampDisplay==='function')updateWinampDisplay();
  },

  // ===================== Generative Pattern-Mutation & Dynamischer Missions-Soundtrack =====================
  mutateCode(code,intensity=0.5){
    let src=String(code||this.currentCode||'');
    if(!src)return src;
    this.mutationCount++;
    const scales=['e:minor','f:minor','c:minor','d:phrygian','g:minor:pentatonic','a2:minor','b:minor','d:major:pentatonic','a:dorian','e:phrygian'];
    const pickScale=scales[(this.mutationCount+Math.floor(Math.random()*scales.length))%scales.length];

    // 1. Mutate scale
    src=src.replace(/(setScale|\.scale)\(\s*["'][^"']+["']\s*\)/g,`$1("${pickScale}")`);

    // 2. Randomly Mute / Un-Mute tracks ($VOICE: ⇄ _$VOICE:)
    const lines = src.split('\n');
    let mutedCount = 0;
    for(let i=0; i<lines.length; i++){
      const l = lines[i];
      // Already muted track: _$FOO: -> 55% chance to un-mute
      if(/^\s*_\$([A-Z0-9_]+)\s*:/.test(l)){
        if(Math.random() < 0.55){
          lines[i] = l.replace(/^\s*_\$([A-Z0-9_]+)\s*:/, '$$$1:');
        }
      }
      // Active track: $FOO: -> 28% chance to mute
      else if(/^\s*\$([A-Z0-9_]+)\s*:/.test(l)){
        if(Math.random() < 0.28 && mutedCount < 2){
          lines[i] = l.replace(/^\s*\$([A-Z0-9_]+)\s*:/, '_$$$1:');
          mutedCount++;
        }
      }
    }
    src = lines.join('\n');

    // 3. Ribbon injection / randomization
    const hasRib = /\.rib\s*\(\s*\d+/.test(src);
    if(hasRib){
      src=src.replace(/\.rib\(\s*\d+\s*,\s*\d+\s*\)/g, ()=>{
        const rSeed = 1 + Math.floor(Math.random()*64);
        const rLen = [2, 4, 8, 16][Math.floor(Math.random()*4)];
        return `.rib(${rSeed}, ${rLen})`;
      });
    } else {
      let injected = false;
      src = src.replace(/(\$(?:THEME|BASS|KICK|PATRON_BASS|SYNTH|LEAD)[^;\n]+\.s\([^)]+\))/g, (match)=>{
        if(!injected && Math.random() < 0.85){
          injected = true;
          const rSeed = 1 + Math.floor(Math.random()*64);
          const rLen = [2, 4, 8][Math.floor(Math.random()*3)];
          return `${match}.rib(${rSeed}, ${rLen})`;
        }
        return match;
      });
    }

    // 4. Random Scramble / Rev / Shuffle / Trancegate
    if(Math.random() < 0.45 && !src.includes('.rev()')){
      src = src.replace(/(\$THEME[^;\n]+)/, '$1.rev()');
    }
    if(Math.random() < 0.40 && !src.includes('.scramble()')){
      src = src.replace(/(\$BASS[^;\n]+)/, '$1.scramble()');
    }

    // 5. Randomly shuffle/permute numeric degree tokens inside n("<...>") or note("<...>")
    src=src.replace(/(?:n|note)\(\s*"<([^"<>]+)>"/g,(full,inner)=>{
      const tokens = inner.trim().split(/\s+/);
      if(tokens.length > 2 && Math.random() < 0.7){
        const mutatedTokens = tokens.map(tok => {
          if(/^\d+$/.test(tok) && Math.random() < 0.5){
            const val = parseInt(tok, 10);
            const shift = [-3, -2, -1, 1, 2, 3, 5][Math.floor(Math.random()*7)];
            return String(Math.max(0, val + shift));
          }
          return tok;
        });
        if(Math.random() < 0.4){
          for(let k=mutatedTokens.length-1; k>0; k--){
            const j=Math.floor(Math.random()*(k+1));
            [mutatedTokens[k], mutatedTokens[j]] = [mutatedTokens[j], mutatedTokens[k]];
          }
        }
        return full.replace(inner, mutatedTokens.join(' '));
      }
      return full;
    });

    // 6. Mutate slider(val) values toward mission intensity
    src=src.replace(/slider\(\s*(0?\.\d+|\d+(?:\.\d+)?)/g,(_,v)=>{
      const cur=parseFloat(v)||0.5;
      const delta=(Math.random()-0.42)*0.22+(intensity-0.5)*0.18;
      const next=Math.max(0.12,Math.min(0.98,cur+delta));
      return `slider(${next.toFixed(3)}`;
    });

    // 7. Adjust setCpm(bpm/4) dynamically
    src=src.replace(/setCpm\(\s*(\d+(?:\.\d+)?)\s*\/\s*4\s*\)/g,(_,bpm)=>{
      const base=parseFloat(bpm)||138;
      const mod=Math.round(Math.max(96,Math.min(182,base+(intensity-0.4)*18+(Math.random()-0.5)*12)));
      return `setCpm(${mod}/4)`;
    });

    return src;
  },

  // Passt den laufenden Soundtrack dynamisch an das Kampfgeschehen an
  updateMissionDynamics(combatState){
    if(!this.dynamicEnabled||!combatState||!combatState.active)return;
    const units=Object.values(combatState.units||{});
    const players=units.filter(u=>u.side==='player'&&!u.dead);
    const enemies=units.filter(u=>u.side==='enemy'&&!u.dead);
    const downed=players.filter(u=>u.downed).length;
    const avgHp=players.length?players.reduce((s,u)=>s+u.hp/Math.max(1,u.maxHp),0)/players.length:1;
    const hasBoss=enemies.some(e=>e.type==='goauld'||e.type==='queen');
    let tension=0.25;
    if(combatState.mission&&combatState.mission.peaceful)tension=0.1;
    else{
      tension=Math.min(1.0,0.25+(enemies.length*0.06)+(1-avgHp)*0.45+(downed*0.2)+(hasBoss?0.3:0));
    }
    this.tension=Math.round(tension*100)/100;
    // Choose fitting Switch Angel track or mutate every 3 rounds
    if(this.mode==='auto'&&this.useSwitchAngelAuto){
      let targetTrack=this.currentTrack;
      if(combatState.mission&&combatState.mission.peaceful){
        targetTrack='sa_curiosity_piano';
      }else if(hasBoss||tension>=0.78){
        const bossPool=['sa_did_i_make_this','sa_whoneedsa303','sa_dubstepacid','sa_amen_infinity'];
        targetTrack=bossPool[(combatState.round||1)%bossPool.length];
      }else{
        const combatPool=['sa_autotomatone','sa_extra_slippy','sa_909workout','sa_hotroller','sa_generative_jungle'];
        targetTrack=combatPool[(combatState.round||1)%combatPool.length];
      }
      if(targetTrack!==this.currentTrack&&STRUDEL_TRACKS[targetTrack]){
        this.currentTrack=targetTrack;
        const baseCode=STRUDEL_TRACKS[targetTrack].code;
        const dynCode=tension>0.55?this.mutateCode(baseCode,tension):baseCode;
        this.evaluate(dynCode,SFX&&!SFX.muted&&SFX.musicEnabled);
      }
    }
  },

  // Speichert einen editierten oder mutierten Song dauerhaft im Spielstand (S.customTracks)
  saveCustomTrack(title,code){
    const cleanTitle=String(title||'').trim()||`Switch Angel Remix #${this.mutationCount+1}`;
    const cleanCode=String(code||this.currentCode||'').trim();
    if(!cleanCode)return {ok:false,msg:'Kein Strudel-Code zum Speichern.'};
    const id='custom_'+Date.now();
    const entry={id,name:`💾 ${cleanTitle}`,title:cleanTitle,artist:'SGC Live-Remix',role:'custom',code:cleanCode};
    STRUDEL_TRACKS[id]=entry;
    this.patterns[id]=cleanCode;
    this.currentTrack=id;
    if(typeof S!=='undefined'&&S){
      if(!S.customTracks)S.customTracks={};
      S.customTracks[id]=entry;
      if(typeof save==='function')save();
    }
    return {ok:true,id,msg:`Track „${cleanTitle}“ im Spielstand gespeichert!`};
  },

  loadCustomTracksFromSave(){
    if(typeof S==='undefined'||!S||!S.customTracks)return;
    for(const [id,entry] of Object.entries(S.customTracks)){
      STRUDEL_TRACKS[id]=entry;
      this.patterns[id]=entry.code;
    }
  },

  _triggerCycle(cycleIdx,cycleDur){
    if(!SFX.ctx||SFX.muted||!SFX.musicEnabled)return;
    const now=SFX.ctx.currentTime;
    this.voices.forEach(v=>{
      if(v.kind==='chord'&&v.degreePattern){
        const baseChord=_CHORD_MAP[String(v.chordName||'cmaj7').toLowerCase()]||_CHORD_MAP.cmaj7;
        const degs=Array.isArray(v.degreePattern)?v.degreePattern:parseMiniNotation(v.degreePattern,cycleIdx).map(e=>e.val);
        const envs=Array.isArray(v.envPattern)?v.envPattern:null;
        const stepCount=degs.length||1,stepDur=cycleDur/stepCount;
        degs.forEach((d,i)=>{
          const env=envs?Number(envs[i]||0):1;
          if(env<=0||d===null||d===undefined)return;
          const degNum=Number(d)||0;
          const midi=baseChord[Math.abs(degNum)%baseChord.length]+Math.floor(degNum/baseChord.length)*12;
          this._scheduleNote(now+i*stepDur,Math.max(0.05,stepDur*0.85),midi,v,env);
        });
        return;
      }
      const evs=parseMiniNotation(v.pattern,cycleIdx);
      evs.forEach(ev=>{
        const startT=now+ev.offset*cycleDur;
        const dur=Math.max(0.03,ev.dur*cycleDur/Math.max(0.25,v._fast)*v._slow);
        if(v.kind==='sound'){
          const tok=String(ev.val||'').trim().toLowerCase();
          if(!tok||tok==='~'||tok==='-'||tok==='0')return;
          SFX._playStrudelNoise(startT,Math.min(dur,v._decay||0.06),v._gain,v._lpf,tok);
        }else{
          const midi=_parseNoteToken(ev.val,v.scaleName);
          if(midi===null)return;
          this._scheduleNote(startT,dur,midi+(v.transposeSemi||0),v,1);
        }
      });
    });
  },

  _scheduleNote(startT,dur,midi,v,vel){
    if(!SFX.ctx||!SFX.musicGain)return;
    const ctx=SFX.ctx;
    const is8Bit=this.chiptuneMode;
    const rb=SFX.rebirth||{bassBank:'tb303_saw',cutoff:2400,resonance:6.0,envMod:0.6,decay:0.28,distortion:0.2,tune:0};

    const sName=String(v.synth||'triangle').toLowerCase();
    const isBass=sName.includes('bass')||sName.includes('303')||sName.includes('acid')||(v.kind==='note'&&midi<58);

    if(isBass){
      STRUDEL.onVoiceTrigger('bass',midi);
      midi+=Number(rb.tune||0);
    }else{
      STRUDEL.onVoiceTrigger('melody',midi);
    }

    const freq=_midiToFreq(midi);
    const osc=ctx.createOscillator();
    const filt=ctx.createBiquadFilter();
    const g=ctx.createGain();

    let synth='triangle';
    if(is8Bit||(isBass&&rb.bassBank==='chiptune')){
      synth='square';
    }else if(isBass){
      if(rb.bassBank==='tb303_sq') synth='square';
      else if(rb.bassBank==='sub') synth='sine';
      else if(rb.bassBank==='slap') synth='triangle';
      else synth='sawtooth'; // tb303_saw, sh101, reese
    }else{
      synth=sName.includes('saw')?'sawtooth':(sName==='pulse'||sName==='square'?'square':(sName==='sine'?'sine':'triangle'));
    }
    osc.type=synth;
    osc.frequency.setValueAtTime(Math.max(24,Math.min(12000,freq)),startT);

    if((is8Bit||(isBass&&rb.bassBank==='chiptune'))&&dur>0.08){
      const arpSemitones=[0,4,7,12];
      const stepT=0.025;
      for(let t=stepT,idx=1;t<dur*0.75;t+=stepT,idx++){
        const shift=arpSemitones[idx%arpSemitones.length];
        osc.frequency.setValueAtTime(_midiToFreq(midi+shift),startT+t);
      }
      osc.frequency.setValueAtTime(freq,startT+dur*0.75);
    }else if(v._slide){
      osc.frequency.exponentialRampToValueAtTime(Math.max(24,freq+v._slide),startT+dur);
    }

    filt.type='lowpass';
    if(isBass&&!is8Bit){
      const cut=rb.cutoff||2400;
      const em=rb.envMod!==undefined?rb.envMod:0.6;
      filt.frequency.setValueAtTime(cut,startT);
      filt.frequency.linearRampToValueAtTime(Math.min(11000,cut*(1+em*2.8)),startT+0.015);
      filt.frequency.exponentialRampToValueAtTime(Math.max(30,cut),startT+Math.min(dur,rb.decay||0.28));
      filt.Q.setValueAtTime(Math.max(0.5,rb.resonance||6),startT);
    }else{
      filt.frequency.setValueAtTime(is8Bit?4200:(v._lpf||1800),startT);
    }

    const peak=Math.max(0.001,Math.min(0.45,(v._gain||0.15)*(vel||1)));
    const atk=is8Bit?0.003:Math.min(dur*0.4,v._attack||0.01);
    const dec=is8Bit?Math.min(dur*0.5,0.08):Math.min(dur*0.6,v._decay||0.15);
    const sus=Math.max(0.001,peak*(v._sustain!==undefined?v._sustain:0.15));
    g.gain.setValueAtTime(0.0001,startT);
    g.gain.linearRampToValueAtTime(peak,startT+atk);
    g.gain.exponentialRampToValueAtTime(sus,startT+atk+dec);
    g.gain.exponentialRampToValueAtTime(0.0001,startT+dur+(v._release||0.05));
    osc.connect(filt);
    filt.connect(g);

    if(isBass&&SFX.distortionNode){
      g.connect(SFX.distortionNode);
    }else{
      g.connect(SFX.musicGain);
    }

    if(v._delay>0&&SFX.delayNode){
      g.connect(SFX.delayNode);
    }
    osc.start(startT);
    osc.stop(startT+dur+(v._release||0.05)+0.02);
  }
};

const SFX={
  ctx:null, master:null, musicGain:null, delayNode:null,
  bassFilter:null, distortionNode:null,
  muted:false, musicEnabled:true, volume:0.65, strudel:STRUDEL,
  tracks:STRUDEL_TRACKS,
  rebirth:{
    bassBank:'tb303_saw',
    kickBank:'tr909',
    hatBank:'tr909',
    cutoff:2400,
    resonance:6.0,
    envMod:0.60,
    decay:0.28,
    distortion:0.20,
    tune:0,
    bdTune:115,
    bdDecay:0.24,
    hatDecay:0.08,
    tempoBpm:140
  },

  setVolume(val){
    const v=Math.max(0,Math.min(1.0,parseFloat(val)));
    this.volume=v;
    if(this.master&&this.ctx){
      this.master.gain.setValueAtTime(this.muted?0:v,this.ctx.currentTime);
    }
    try{localStorage.setItem('sgc_volume',String(v));}catch(e){}
    return v;
  },

  getVolume(){
    if(typeof localStorage!=='undefined'){
      const s=localStorage.getItem('sgc_volume');
      if(s!==null){
        const pv=parseFloat(s);
        if(!isNaN(pv))return pv;
      }
    }
    return this.volume!==undefined?this.volume:0.65;
  },

  setSoundBank(type, bankId){
    if(!this.rebirth)return;
    if(type==='kick') this.rebirth.kickBank=bankId;
    else if(type==='hat') this.rebirth.hatBank=bankId;
    else if(type==='bass') this.rebirth.bassBank=bankId;
    if(typeof updateRebirthUI==='function') updateRebirthUI();
    if(typeof toast==='function'){
      const name = type==='kick'?'Kick':type==='hat'?'Hi-Hat':'Bass';
      toast(`🔊 ${name}-Soundbank: ${bankId.toUpperCase()}`);
    }
  },

  setRebirthParam(param, val){
    if(!this.rebirth)return;
    const num=Number(val);
    if(isNaN(num))return;
    this.rebirth[param]=num;
    if(this.ctx){
      const now=this.ctx.currentTime;
      if(param==='cutoff'&&this.bassFilter){
        this.bassFilter.frequency.setTargetAtTime(Math.max(40,Math.min(10000,num)),now,0.01);
      }else if(param==='resonance'&&this.bassFilter){
        this.bassFilter.Q.setTargetAtTime(Math.max(0.1,Math.min(25,num)),now,0.01);
      }else if(param==='distortion'&&this.distortionNode){
        this.distortionNode.curve=_makeDistortionCurve(num*50);
      }else if(param==='tempoBpm'){
        STRUDEL.setCpm(num/4);
      }
    }
    if(typeof updateRebirthParamReadout==='function') updateRebirthParamReadout(param,num);
  },

  init(){
    if(this.ctx||typeof window==='undefined')return;
    try{
      this.ctx=new (window.AudioContext||window.webkitAudioContext)();
      const currentVol=this.getVolume();
      this.master=this.ctx.createGain();
      this.master.gain.value=this.muted?0:currentVol;

      this.analyser=this.ctx.createAnalyser();
      this.analyser.fftSize=512;
      this.analyser.smoothingTimeConstant=0.8;
      this.master.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);

      // Route any third-party Web Audio nodes (Superdough / Strudel Web) directly through Master Gain & Analyser
      if(!AudioNode.prototype._sgcHooked){
        AudioNode.prototype._sgcHooked=true;
        const origConnect=AudioNode.prototype.connect;
        const self=this;
        AudioNode.prototype.connect=function(dest,...args){
          if(dest&&self&&self.ctx&&dest===self.ctx.destination&&this!==self.analyser&&this!==self.master){
            return origConnect.call(this,self.master,...args);
          }
          return origConnect.call(this,dest,...args);
        };
      }

      this.musicGain=this.ctx.createGain();
      this.musicGain.gain.value=this.musicEnabled?0.48:0;
      this.musicGain.connect(this.master);

      // ReBirth TB-303 Bass DSP chain (Filter -> Waveshaper Distortion -> Master Music Gain)
      this.bassFilter=this.ctx.createBiquadFilter();
      this.bassFilter.type='lowpass';
      this.bassFilter.frequency.value=this.rebirth.cutoff||2400;
      this.bassFilter.Q.value=this.rebirth.resonance||6.0;

      this.distortionNode=this.ctx.createWaveShaper();
      this.distortionNode.curve=_makeDistortionCurve((this.rebirth.distortion||0.2)*50);
      this.distortionNode.oversample='4x';

      this.bassFilter.connect(this.distortionNode);
      this.distortionNode.connect(this.musicGain);

      this.delayNode=this.ctx.createDelay(1.0);
      this.delayNode.delayTime.value=0.28;
      const fb=this.ctx.createGain();
      fb.gain.value=0.24;
      const df=this.ctx.createBiquadFilter();
      df.type='lowpass';df.frequency.value=1400;
      this.delayNode.connect(df);
      df.connect(fb);
      fb.connect(this.delayNode);
      df.connect(this.musicGain);

      STRUDEL.loadCustomTracksFromSave();
      STRUDEL.ensureWebRepl().then(()=>{
        if(!this.muted&&this.musicEnabled){
          this.playTrack(STRUDEL.currentTrack||'sa_lets_talk');
        }
      });
    }catch(e){this.ctx=null;}
  },

  resume(){
    if(this.ctx&&this.ctx.state==='suspended')this.ctx.resume();
    if(this.ctx&&!STRUDEL.playing&&this.musicEnabled&&!this.muted){
      this.playTrack(STRUDEL.currentTrack||'sa_lets_talk');
    }
  },

  stop(){
    STRUDEL.hush();
    STRUDEL.playing=false;
    STRUDEL.paused=false;
    if(typeof updateWinampDisplay==='function')updateWinampDisplay();
  },

  pause(){
    if(STRUDEL.playing){
      STRUDEL.hush();
      STRUDEL.paused=true;
    }else if(STRUDEL.paused){
      STRUDEL.paused=false;
      this.playTrack(STRUDEL.currentTrack||'sa_lets_talk');
    }
    if(typeof updateWinampDisplay==='function')updateWinampDisplay();
  },

  prevTrack(){
    const keys=Object.keys(STRUDEL_TRACKS);
    const idx=keys.indexOf(STRUDEL.currentTrack);
    const prev=keys[(idx-1+keys.length)%keys.length];
    this.playTrack(prev);
  },

  nextTrack(){
    const keys=Object.keys(STRUDEL_TRACKS);
    const idx=keys.indexOf(STRUDEL.currentTrack);
    const next=keys[(idx+1)%keys.length];
    this.playTrack(next);
  },

  toggle(){
    this.muted=!this.muted;
    if(this.master)this.master.gain.value=this.muted?0:0.55;
    if(this.muted)STRUDEL.hush();
    else if(this.musicEnabled)this.playTrack(STRUDEL.currentTrack||'sa_lets_talk');
    if(typeof updateWinampDisplay==='function')updateWinampDisplay();
    return this.muted;
  },

  toggleMusic(){
    this.musicEnabled=!this.musicEnabled;
    if(this.musicGain)this.musicGain.gain.value=this.musicEnabled?0.48:0;
    if(!this.musicEnabled)STRUDEL.hush();
    else if(!this.muted)this.playTrack(STRUDEL.currentTrack||'sa_lets_talk');
    if(typeof updateWinampDisplay==='function')updateWinampDisplay();
    return this.musicEnabled;
  },

  playTrack(trackKey){
    STRUDEL.paused=false;
    STRUDEL.loadCustomTracksFromSave();
    if(trackKey==='custom'&&STRUDEL.customCode){
      STRUDEL.currentTrack='custom';
      STRUDEL.evaluate(STRUDEL.customCode,!this.muted&&this.musicEnabled);
      if(typeof updateWinampDisplay==='function')updateWinampDisplay();
      return;
    }
    const tr=STRUDEL_TRACKS[trackKey]||STRUDEL_TRACKS.sa_lets_talk||STRUDEL_TRACKS.base;
    STRUDEL.currentTrack=STRUDEL_TRACKS[trackKey]?trackKey:'base';
    STRUDEL.evaluate(tr.code,!this.muted&&this.musicEnabled);
    if(typeof updateWinampDisplay==='function')updateWinampDisplay();
  },

  setTrackMode(mode){
    STRUDEL.mode=mode||'auto';
    if(STRUDEL.mode!=='auto'){
      this.playTrack(STRUDEL.mode);
    }else{
      this.syncContext(this._lastContext||'base');
    }
  },

  syncContext(contextKey){
    this._lastContext=contextKey;
    if(STRUDEL.mode!=='auto')return;
    // Map contextKey ('base', 'map', 'planet', 'gate', 'combat', 'peaceful', 'boss') to Switch Angel or SGC track
    let target=contextKey;
    if(STRUDEL.useSwitchAngelAuto&&typeof SWITCH_ANGEL_TRACKS!=='undefined'){
      const roleMap={
        base:['sa_lets_talk','sa_patronbeat','sa_waning_pad','theme_remix_lofi'],
        map:['sa_its_giving_tycho','sa_sky_looks_back','theme_remix_1'],
        planet:['sa_canyonhopper','sa_openup','sa_mutek4am','sa_sentimental_dnb'],
        gate:['sa_in_the_beginning','theme_fanfare'],
        combat:['theme_remix_2','theme_remix_cnc','sa_autotomatone','sa_extra_slippy','sa_909workout','sa_hotroller','sa_generative_jungle','sa_amen_infinity'],
        peaceful:['theme_remix_lofi','sa_curiosity_piano'],
        boss:['theme_remix_cnc','sa_did_i_make_this','sa_whoneedsa303','sa_dubstepacid']
      };
      const pool=roleMap[contextKey];
      if(pool&&pool.length){
        const daySeed=(typeof S!=='undefined'&&S&&S.day)||1;
        target=pool[(daySeed-1)%pool.length];
      }
    }
    if(STRUDEL.currentTrack!==target||!STRUDEL.playing){
      this.playTrack(target);
    }
  },
  music(trackKey){
    this.syncContext(trackKey);
  },

  evalCustomPattern(code){
    STRUDEL.customCode=String(code||'');
    STRUDEL.mode='custom';
    this.init();this.resume();
    STRUDEL.evaluate(STRUDEL.customCode,true);
  },

  _playStrudelNoise(startT,dur,vol,filterFreq,kind){
    if(!this.ctx||this.muted||!this.musicGain)return;
    const k=String(kind||'white').split(':')[0];
    const rb=this.rebirth||{kickBank:'tr909',hatBank:'tr909',bdTune:115,bdDecay:0.24,hatDecay:0.08};

    // --- KICK DRUM ENGINE (TR-909 / TR-808 / TR-707 / Linn / 8-Bit / Acoustic / Acid) ---
    if(k==='bd'||k==='sbd'||k==='lt'||k.includes('kick')){
      STRUDEL.onVoiceTrigger('kick',36);
      const bank=rb.kickBank||'tr909';
      const o=this.ctx.createOscillator();
      const g=this.ctx.createGain();
      const tune=rb.bdTune||115;
      const decay=rb.bdDecay||0.24;

      if(bank==='tr808'){
        // Roland TR-808: Deep booming sine wave sub drop
        o.type='sine';
        o.frequency.setValueAtTime(Math.max(30,tune*0.88),startT);
        o.frequency.exponentialRampToValueAtTime(32,startT+Math.min(0.8,decay*1.5));
        g.gain.setValueAtTime(Math.min(0.48,(vol||0.25)*2.4),startT);
        g.gain.exponentialRampToValueAtTime(0.001,startT+Math.min(0.9,decay*1.6));
        o.connect(g);g.connect(this.musicGain);
        o.start(startT);o.stop(startT+Math.min(0.92,decay*1.62));
      }else if(bank==='tr707'){
        // Roland TR-707: Tight punchy digital 80s kick
        o.type='triangle';
        o.frequency.setValueAtTime(130,startT);
        o.frequency.exponentialRampToValueAtTime(52,startT+0.14);
        g.gain.setValueAtTime(Math.min(0.42,(vol||0.25)*2.1),startT);
        g.gain.exponentialRampToValueAtTime(0.001,startT+0.17);
        o.connect(g);g.connect(this.musicGain);
        o.start(startT);o.stop(startT+0.18);
      }else if(bank==='linn'){
        // LinnDrum: Crisp vintage attack with mid punch
        o.type='triangle';
        o.frequency.setValueAtTime(145,startT);
        o.frequency.exponentialRampToValueAtTime(48,startT+0.18);
        g.gain.setValueAtTime(Math.min(0.45,(vol||0.25)*2.2),startT);
        g.gain.exponentialRampToValueAtTime(0.001,startT+0.22);
        o.connect(g);g.connect(this.musicGain);
        o.start(startT);o.stop(startT+0.23);
      }else if(bank==='chiptune'){
        // 8-Bit NES Kick: Rapid descending square chirp
        o.type='square';
        o.frequency.setValueAtTime(160,startT);
        o.frequency.setValueAtTime(110,startT+0.015);
        o.frequency.setValueAtTime(70,startT+0.035);
        o.frequency.setValueAtTime(45,startT+0.065);
        g.gain.setValueAtTime(Math.min(0.35,(vol||0.25)*1.8),startT);
        g.gain.exponentialRampToValueAtTime(0.001,startT+0.12);
        o.connect(g);g.connect(this.musicGain);
        o.start(startT);o.stop(startT+0.13);
      }else if(bank==='acoustic'){
        // Acoustic Orchestral Timpani Kick
        o.type='sine';
        o.frequency.setValueAtTime(95,startT);
        o.frequency.exponentialRampToValueAtTime(42,startT+decay);
        g.gain.setValueAtTime(Math.min(0.45,(vol||0.25)*2.3),startT);
        g.gain.exponentialRampToValueAtTime(0.001,startT+decay+0.05);
        o.connect(g);g.connect(this.musicGain);
        o.start(startT);o.stop(startT+decay+0.06);
      }else if(bank==='acid'){
        // Saturated Acid Gabber Kick
        o.type='sawtooth';
        o.frequency.setValueAtTime(160,startT);
        o.frequency.exponentialRampToValueAtTime(38,startT+decay);
        g.gain.setValueAtTime(Math.min(0.5,(vol||0.25)*2.5),startT);
        g.gain.exponentialRampToValueAtTime(0.001,startT+decay+0.04);
        o.connect(g);
        if(this.distortionNode){o.connect(this.distortionNode);}
        else{o.connect(this.musicGain);}
        o.start(startT);o.stop(startT+decay+0.05);
      }else{
        // Roland TR-909 (Standard): Punchy club beater + triangle body
        o.type='triangle';
        o.frequency.setValueAtTime(Math.max(40,tune),startT);
        o.frequency.exponentialRampToValueAtTime(40,startT+decay);
        g.gain.setValueAtTime(Math.min(0.45,(vol||0.25)*2.3),startT);
        g.gain.exponentialRampToValueAtTime(0.001,startT+decay+0.04);
        o.connect(g);g.connect(this.musicGain);
        o.start(startT);o.stop(startT+decay+0.05);
      }
      return;
    }

    // --- HI-HAT ENGINE (TR-909 / TR-808 / TR-707 / Linn / 8-Bit / Noise Sweep) ---
    if(k==='hh'||k==='oh'||k==='noisehat'||k.includes('hat')){
      STRUDEL.onVoiceTrigger('hat',42);
      const bank=rb.hatBank||'tr909';
      const hatDec=rb.hatDecay||(k==='oh'?0.22:0.08);
      const n=Math.max(16,Math.floor(this.ctx.sampleRate*Math.min(dur,hatDec)));
      const buf=this.ctx.createBuffer(1,n,this.ctx.sampleRate);
      const d=buf.getChannelData(0);

      if(bank==='chiptune'){
        // 4-bit LFSR noise
        let lfsr=0x7ace;
        for(let i=0;i<n;i++){
          lfsr=(lfsr>>1)^(-(lfsr&1)&0xb400);
          d[i]=((lfsr&0x0f)/7.5-1)*(1-i/n);
        }
      }else{
        for(let i=0;i<n;i++){
          d[i]=(Math.random()*2-1)*Math.pow(1-i/n,1.5);
        }
      }

      const src=this.ctx.createBufferSource();src.buffer=buf;
      const f=this.ctx.createBiquadFilter();
      if(bank==='tr808'){
        // Roland TR-808: Metallic bandpass sizzle centered at 7200Hz, high Q
        f.type='bandpass';
        f.frequency.value=7200;
        f.Q.value=4.5;
      }else if(bank==='tr707'){
        f.type='highpass';
        f.frequency.value=6000;
      }else if(bank==='linn'){
        f.type='bandpass';
        f.frequency.value=8200;
        f.Q.value=2.2;
      }else{
        // Roland TR-909: Crisp highpassed noise at 8500Hz
        f.type='highpass';
        f.frequency.value=8500;
      }

      const g=this.ctx.createGain();
      g.gain.setValueAtTime(Math.max(0.001,(vol||0.04)*(bank==='tr808'?1.8:1.2)),startT);
      g.gain.exponentialRampToValueAtTime(0.0001,startT+Math.min(dur,hatDec));
      src.connect(f);f.connect(g);g.connect(this.musicGain);
      src.start(startT);
      return;
    }

    // --- SNARE / CLAP ---
    if(k==='sd'||k==='cp'||k==='snare'||k==='rim'){
      STRUDEL.onVoiceTrigger('snare',38);
    }

    const n=Math.max(16,Math.floor(this.ctx.sampleRate*dur));
    const buf=this.ctx.createBuffer(1,n,this.ctx.sampleRate),d=buf.getChannelData(0);
    let b0=0;
    for(let i=0;i<n;i++){
      const w=(Math.random()*2-1)*(1-i/n);
      b0=k==='pink'||k==='brown'?(0.85*b0+0.15*w):w;
      d[i]=b0;
    }
    const src=this.ctx.createBufferSource();src.buffer=buf;
    const f=this.ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=filterFreq||2500;
    const g=this.ctx.createGain();
    g.gain.setValueAtTime(Math.max(0.001,vol||0.04),startT);
    g.gain.exponentialRampToValueAtTime(0.0001,startT+dur);
    src.connect(f);f.connect(g);g.connect(this.musicGain);
    src.start(startT);
  },

  tone(freq,dur,type,vol,slideTo){
    if(!this.ctx||this.muted)return;type=type||'square';vol=vol||0.3;
    const t=this.ctx.currentTime,o=this.ctx.createOscillator(),g=this.ctx.createGain();
    o.type=type;o.frequency.setValueAtTime(freq,t);
    if(slideTo)o.frequency.exponentialRampToValueAtTime(Math.max(1,slideTo),t+dur);
    g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(0.001,t+dur);
    o.connect(g);g.connect(this.master);o.start(t);o.stop(t+dur+0.02);
  },
  noise(dur,vol,filterFreq){
    if(!this.ctx||this.muted)return;vol=vol||0.3;filterFreq=filterFreq||1000;
    const t=this.ctx.currentTime,n=Math.floor(this.ctx.sampleRate*dur);
    const buf=this.ctx.createBuffer(1,n,this.ctx.sampleRate),d=buf.getChannelData(0);
    for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*(1-i/n);
    const src=this.ctx.createBufferSource();src.buffer=buf;
    const f=this.ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=filterFreq;
    const g=this.ctx.createGain();g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(0.001,t+dur);
    src.connect(f);f.connect(g);g.connect(this.master);src.start(t);
  },
  shoot(){ this.noise(0.12,0.25,3000); this.tone(880,0.1,'square',0.15,220); },
  shotgun(){ this.noise(0.2,0.4,1500); this.tone(220,0.15,'square',0.2,80); },
  zat(){ this.tone(1400,0.14,'sine',0.22,320); this.tone(700,0.12,'triangle',0.15,1600); },
  staff(){ this.noise(0.18,0.3,1200); this.tone(360,0.18,'sawtooth',0.22,95); },
  turret(){ this.noise(0.09,0.22,3500); this.tone(640,0.08,'square',0.16,180); },
  melee(){ this.tone(150,0.12,'sine',0.35,60); this.noise(0.08,0.2,800); },
  hit(){ this.tone(300,0.08,'sawtooth',0.25,100); this.noise(0.06,0.15,2000); },
  miss(){ this.noise(0.15,0.1,4000); this.tone(600,0.15,'sine',0.08,900); },
  death(){ this.tone(200,0.4,'sawtooth',0.3,40); this.noise(0.3,0.2,600); },
  special(){ this.tone(520,0.12,'sine',0.22,880); setTimeout(()=>this.tone(880,0.16,'triangle',0.18,1180),80); },
  gate(){
    if(!this.ctx||this.muted)return;
    const t=this.ctx.currentTime,o=this.ctx.createOscillator(),g=this.ctx.createGain();
    o.type='sine';o.frequency.setValueAtTime(80,t);
    o.frequency.exponentialRampToValueAtTime(600,t+0.8);
    o.frequency.exponentialRampToValueAtTime(120,t+1.6);
    g.gain.setValueAtTime(0.001,t);
    g.gain.exponentialRampToValueAtTime(0.3,t+0.4);
    g.gain.exponentialRampToValueAtTime(0.001,t+1.8);
    o.connect(g);g.connect(this.master);o.start(t);o.stop(t+1.9);
    this.noise(1.2,0.1,800);
  },
  click(){ this.tone(1200,0.04,'square',0.1); },
  build(){ this.tone(400,0.1,'square',0.15,600); this.noise(0.1,0.1,1000); },
  victory(){ [523,659,784,1047].forEach((f,i)=>setTimeout(()=>this.tone(f,0.25,'square',0.2),i*120)); },
  defeat(){ [400,350,300,200].forEach((f,i)=>setTimeout(()=>this.tone(f,0.3,'sawtooth',0.2),i*150)); },
};

// Vorab-Kompilieren des Standard-Patterns
STRUDEL.compile((STRUDEL_TRACKS.sa_lets_talk||STRUDEL_TRACKS.base).code);

if(typeof window!=='undefined'){
  window.STRUDEL=STRUDEL;
  window.SFX=SFX;
  window.STRUDEL_TRACKS=STRUDEL_TRACKS;
  const unlock=()=>{SFX.init();SFX.resume();};
  window.addEventListener('pointerdown',unlock);
  window.addEventListener('keydown',unlock);
}
if(typeof global!=='undefined'){
  global.STRUDEL=STRUDEL;
  global.SFX=SFX;
  global.STRUDEL_TRACKS=STRUDEL_TRACKS;
}
if(typeof module!=='undefined'&&module.exports){
  module.exports={STRUDEL,SFX,STRUDEL_TRACKS,preprocessSwitchAngelCode};
}
